@extends('layouts.master')
@section('content')
 
<div class="container-fluid">
	<div class="inner-contents">
		<div class="card border-0">
			<div class="card-header bg-transparent border-0 p-5 pb-0">
				<span class="col-lg-12 row">
					<h3 class="mb-0 col-lg-6"> {{$m_data['m_name']}} Metta Data</h3>
				</span>
			</div>
			<div class="card-body pt-3 collapse multi-collapse show" id="metta_div_id">
				<form action="{{route('metta.update')}}" id="myform_1" method="post" enctype="multipart/form-data">
					@csrf
					{{method_field('put')}}
					<input type="hidden" name="m_id" value="{{$m_data['m_id']}}">
					<input type="hidden" name="m_slug" value="{{$m_data['m_slug']}}">
					<div class="row">
						<div class="form-group col-sm-6">
							<label class="form-label">Metta Title</label>
							<input type="text" name="metta_title" value="{{$m_data['metta_title']}}" class="form-control" placeholder="Enter Title">
						</div>
						<div class=" form-group col-md-6 "> 
							<label class="form-label">Banner Image</label>
							<input type="file" class="fileupload form-control " name="m_banner_img" id="avatar"  value="{{$m_data['m_banner_img']}} " >									  
							<label class="col-md-12 "> {{$m_data['m_banner_img']}}
							</label>	 
						</div>
						<div class="form-group col-lg-6"> 
							<label class="form-label">Metta Description</label>
							<textarea class="form-control" name="metta_desc" placeholder="Metta Description">{{$m_data['metta_desc']}}</textarea> 
						</div>
						<div class="form-group col-lg-6"> 
							<label class="form-label">Metta Keyword</label>
							<textarea class="form-control" name="metta_keywords" placeholder="Metta Keyword">{{$m_data['metta_keywords']}}</textarea> 
						</div>
					</div>
					<div class="form-group">
						<button type="submit" class="btn btn-primary submit_btn">Save</button>
					</div>
				</form>
			</div>
		</div>
		
	</div>
</div>

<script>
	$(function () {
	  
	  $('#myform_1').validate({
	    rules: {
	        metta_title: {
	        required: true
	      }, 
	      metta_desc: {
	        required: true
	      },
	      metta_keywords: {
	        required: true
	      }, 
	    },
	    messages: {
	      metta_title: "Please enter your name", 
	      metta_desc: "Please enter the metta description",
	      metta_keywords: "Please senter the metta keyword", 
	
	    },
		
		submitHandler: function (form) { // for demo  
	        console.log('55555');
			$('.submit_btn').submit();
		},
	    errorElement: 'span',
	    errorPlacement: function (error, element) {
	      error.addClass('invalid-feedback');
	      element.closest('.form-group').append(error);
	    },
	    highlight: function (element, errorClass, validClass) {
	      $(element).addClass('is-invalid');
	    },
	    unhighlight: function (element, errorClass, validClass) {
	      $(element).removeClass('is-invalid');
	    }
	  });
	
	    $('#myform_2').validate({
	    rules: {
	        metta_title: {
	        required: true
	      }, 
	      metta_desc: {
	        required: true
	      },
	      metta_keywords: {
	        required: true
	      }, 
	    },
	    messages: {
	      metta_title: "Please enter your name", 
	      metta_desc: "Please enter the metta description",
	      metta_keywords: "Please senter the metta keyword", 
	
	    },
		
		submitHandler: function (form) { // for demo  
	        console.log('55555');
			$('.submit_btn').submit();
		},
	    errorElement: 'span',
	    errorPlacement: function (error, element) {
	      error.addClass('invalid-feedback');
	      element.closest('.form-group').append(error);
	    },
	    highlight: function (element, errorClass, validClass) {
	      $(element).addClass('is-invalid');
	    },
	    unhighlight: function (element, errorClass, validClass) {
	      $(element).removeClass('is-invalid');
	    }
	  });
	});
</script>

<script>
   CKEDITOR.replace( 'md_desc_2' );
</script>
@endsection