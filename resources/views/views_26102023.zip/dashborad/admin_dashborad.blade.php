@extends('layouts.master')
@section('content')
<div class="container-fluid">
                <div class="inner-contents">

                    <div class="row">
                        <div class="col-xxl-3 col-lg-6">
                            <div class="page-header d-flex align-items-center justify-content-between mr-bottom-30">
                                <div class="left-part">
                                    <h2 class="text-dark">Email</h2>
                                    <p class="text-gray mb-0">Lorem ipsum  dolor sit amet </p>
                                </div>
                            </div>

                            <div class="email-page-left">
                                <div class="card border-0">
                                    <div class="card-body">
                                        <ul class="message-box p-0 list-unstyled" id="pills-tab" role="tablist">
                                            <li>
                                                <a class=" active d-flex align-items-center justify-content-between gap-4 p-3 px-4" href="#inbox-tab" data-bs-toggle="tab" role="tab">
                                                    <div class="flex-grow-1">
                                                        <h5 class="mb-0"><i class="bi bi-envelope-paper-fill me-2"></i> Inbox</h5>
                                                    </div>
                                                    <div class="message-number flex-shrink-0 bg-info rounded d-inline-block text-center ff-heading fw-semibold text-white ">17</div>
                                                </a>
                                            </li>
                                        
                                            <li>
                                                <a class=" d-flex align-items-center justify-content-between gap-4 p-3 px-4" href="#sent-tab" data-bs-toggle="tab" role="tab">
                                                    <div class="flex-grow-1">
                                                        <h5 class="mb-0"><i class="bi bi-send me-2"></i> Sent</h5>
                                                    </div>
                                                    <div class="message-number flex-shrink-0 bg-info rounded d-inline-block text-center ff-heading fw-semibold text-white ">09</div>
                                                </a>
                                            </li>
                                        
                                            <li>
                                                <a class=" d-flex align-items-center justify-content-between gap-4 p-3 px-4" href="#draft-tab" data-bs-toggle="tab" role="tab">
                                                    <div class="flex-grow-1">
                                                        <h5 class="mb-0"><i class="bi bi-envelope-paper-fill me-2"></i> Draft</h5>
                                                    </div>
                                                    <div class="message-number flex-shrink-0 bg-info rounded d-inline-block text-center ff-heading fw-semibold text-white ">17</div>
                                                </a>
                                            </li>
                                        
                                            <li>
                                                <a class=" d-flex align-items-center justify-content-between gap-4 p-3 px-4" href="#archived-tab" data-bs-toggle="tab" role="tab">
                                                    <div class="flex-grow-1">
                                                        <h5 class="mb-0"><i class="bi bi-archive-fill me-2"></i> Archived</h5>
                                                    </div>
                                                    <div class="message-number flex-shrink-0 bg-info rounded d-inline-block text-center ff-heading fw-semibold text-white ">27</div>
                                                </a>
                                            </li>
                                        
                                            <li>
                                                <a class=" d-flex align-items-center justify-content-between gap-4 p-3 px-4" href="#favorite-tab" data-bs-toggle="tab" role="tab">
                                                    <div class="flex-grow-1">
                                                        <h5 class="mb-0"><i class="bi bi-star-fill me-2"></i> Favorite</h5>
                                                    </div>
                                                    <div class="message-number flex-shrink-0 bg-info rounded d-inline-block text-center ff-heading fw-semibold text-white ">17</div>
                                                </a>
                                            </li>
                                        
                                            <li>
                                                <a class=" d-flex align-items-center justify-content-between gap-4 p-3 px-4" href="#spam-tab" data-bs-toggle="tab" role="tab">
                                                    <div class="flex-grow-1">
                                                        <h5 class="mb-0"><i class="bi bi-folder-symlink me-2"></i> Spam</h5>
                                                    </div>
                                                    <div class="message-number flex-shrink-0 bg-info rounded d-inline-block text-center ff-heading fw-semibold text-white ">17</div>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-4 col-lg-6 pe-xxl-0">
                            <div class="email-page-right">
                                <div class="tab-content message-list">
                                    <div class="tab-pane fade show active" id="inbox-tab" role="tabpanel">
                                        <div class="card border-0">
                                            <div class="card-header border-0 p-5 pb-3">
                                                <div class="w-100 mb-5 position-relative">
                                                    <form class="search-form" action="https://wpthemebooster.com/demo/themeforest/html/kleon/search.php">
                                                        <input type="text" name="search" class="form-control rounded-3 w-100" placeholder="Search">
                                                        <button type="submit" class="btn"><img src="assets/img/svg/search.svg" alt=""></button>
                                                    </form>
                                                </div>
                                                <div class="dropdown-wrapper--title">
                                                    <h5 class="d-flex align-items-center justify-content-between text-uppercase text-dark">Recent Message 
                                                        <a href="#" data-bs-toggle="dropdown" class="fs-24 text-gray"><i class="bi bi-three-dots-vertical"></i></a>
                                                        
                                                        <div class="dropdown-menu p-0">
                                                            <a class="dropdown-item" href="#">Important</a>
                                                            <a class="dropdown-item" href="#">Trash</a>
                                                            <a class="dropdown-item" href="#">Important</a>
                                                        </div>
                                                    </h5>
                                                </div>
                                            </div>
                                            <div class="card-body p-0">
                                                <div class="dropdown-widget p-0">
                                                    <div class="dropdown-wrapper">
                                                        <ul class="notification-board list-unstyled">
                                                            <li class="author-online has-new-message">
                                                                <a  href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/15.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Margaretha <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class="active d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/14.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">John Doe <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/13.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Marissa Joana <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/12.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Juminten <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/11.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Richard Hunters <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/10.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Clara Clarisa <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/9.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Vasa Line <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>                                            
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="sent-tab" role="tabpanel">
                                        <div class="card border-0">
                                            <div class="card-header border-0 p-5 mb-3">
                                                <div class="w-100 mb-5 position-relative">
                                                    <form class="search-form" action="https://wpthemebooster.com/demo/themeforest/html/kleon/search.php">
                                                        <input type="text" name="search" class="form-control rounded-3 w-100" placeholder="Search">
                                                        <button type="submit" class="btn"><img src="assets/img/svg/search.svg" alt=""></button>
                                                    </form>
                                                </div>
                                                <div class="dropdown-wrapper--title">
                                                    <h4 class="d-flex align-items-center justify-content-between text-uppercase text-gray">Recent Message 
                                                        <a href="#" data-bs-toggle="dropdown" class="fs-24 text-gray"><i class="bi bi-three-dots-vertical"></i></a>
                                                        
                                                        <div class="dropdown-menu p-0">
                                                            <a class="dropdown-item" href="#">Important</a>
                                                            <a class="dropdown-item" href="#">Trash</a>
                                                            <a class="dropdown-item" href="#">Important</a>
                                                        </div>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="card-body p-0">
                                                <div class="dropdown-widget p-0">
                                                    <div class="dropdown-wrapper">
                                                        <ul class="notification-board list-unstyled">
                                                            <li class="author-online has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/8.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Margaretha <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/7.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">John Doe <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/6.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Marissa Joana <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/5.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Juminten <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/4.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Richard Hunters <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/3.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Clara Clarisa <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/2.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Vasa Line <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>                                            
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="draft-tab" role="tabpanel">
                                        <div class="card border-0">
                                            <div class="card-header border-0 p-5 mb-3">
                                                <div class="w-100 mb-5 position-relative">
                                                    <form class="search-form" action="https://wpthemebooster.com/demo/themeforest/html/kleon/search.php">
                                                        <input type="text" name="search" class="form-control rounded-3 w-100" placeholder="Search">
                                                        <button type="submit" class="btn"><img src="assets/img/svg/search.svg" alt=""></button>
                                                    </form>
                                                </div>
                                                <div class="dropdown-wrapper--title">
                                                    <h4 class="d-flex align-items-center justify-content-between text-uppercase text-gray">Recent Message 
                                                        <a href="#" data-bs-toggle="dropdown" class="fs-24 text-gray"><i class="bi bi-three-dots-vertical"></i></a>
                                                        
                                                        <div class="dropdown-menu p-0">
                                                            <a class="dropdown-item" href="#">Important</a>
                                                            <a class="dropdown-item" href="#">Trash</a>
                                                            <a class="dropdown-item" href="#">Important</a>
                                                        </div>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="card-body p-0">
                                                <div class="dropdown-widget p-0">
                                                    <div class="dropdown-wrapper">
                                                        <ul class="notification-board list-unstyled">
                                                            <li class="author-online has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/1.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Margaretha <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/2.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">John Doe <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/3.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Marissa Joana <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/4.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Juminten <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/5.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Richard Hunters <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/6.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Clara Clarisa <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/7.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Vasa Line <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>                                            
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="archived-tab" role="tabpanel">
                                        <div class="card border-0">
                                            <div class="card-header border-0 p-5 mb-3">
                                                <div class="w-100 mb-5 position-relative">
                                                    <form class="search-form" action="https://wpthemebooster.com/demo/themeforest/html/kleon/search.php">
                                                        <input type="text" name="search" class="form-control rounded-3 w-100" placeholder="Search">
                                                        <button type="submit" class="btn"><img src="assets/img/svg/search.svg" alt=""></button>
                                                    </form>
                                                </div>
                                                <div class="dropdown-wrapper--title">
                                                    <h4 class="d-flex align-items-center justify-content-between text-uppercase text-gray">Recent Message 
                                                        <a href="#" data-bs-toggle="dropdown" class="fs-24 text-gray"><i class="bi bi-three-dots-vertical"></i></a>
                                                        
                                                        <div class="dropdown-menu p-0">
                                                            <a class="dropdown-item" href="#">Important</a>
                                                            <a class="dropdown-item" href="#">Trash</a>
                                                            <a class="dropdown-item" href="#">Important</a>
                                                        </div>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="card-body p-0">
                                                <div class="dropdown-widget p-0">
                                                    <div class="dropdown-wrapper">
                                                        <ul class="notification-board list-unstyled">
                                                            <li class="author-online has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/8.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Margaretha <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/9.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">John Doe <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/10.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Marissa Joana <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/11.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Juminten <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/12.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Richard Hunters <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/13.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Clara Clarisa <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/14.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Vasa Line <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>                                            
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="favorite-tab" role="tabpanel">
                                        <div class="card border-0">
                                            <div class="card-header border-0 p-5 mb-3">
                                                <div class="w-100 mb-5 position-relative">
                                                    <form class="search-form" action="https://wpthemebooster.com/demo/themeforest/html/kleon/search.php">
                                                        <input type="text" name="search" class="form-control rounded-3 w-100" placeholder="Search">
                                                        <button type="submit" class="btn"><img src="assets/img/svg/search.svg" alt=""></button>
                                                    </form>
                                                </div>
                                                <div class="dropdown-wrapper--title">
                                                    <h4 class="d-flex align-items-center justify-content-between text-uppercase text-gray">Recent Message 
                                                        <a href="#" data-bs-toggle="dropdown" class="fs-24 text-gray"><i class="bi bi-three-dots-vertical"></i></a>
                                                        
                                                        <div class="dropdown-menu p-0">
                                                            <a class="dropdown-item" href="#">Important</a>
                                                            <a class="dropdown-item" href="#">Trash</a>
                                                            <a class="dropdown-item" href="#">Important</a>
                                                        </div>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="card-body p-0">
                                                <div class="dropdown-widget p-0">
                                                    <div class="dropdown-wrapper">
                                                        <ul class="notification-board list-unstyled">
                                                            <li class="author-online has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/15.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Margaretha <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/14.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">John Doe <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/13.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Marissa Joana <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/12.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Juminten <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/11.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Richard Hunters <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/10.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Clara Clarisa <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/9.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Vasa Line <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>                                            
                                            </div>
                                        </div>
                                    </div>

                                    <div class="tab-pane fade" id="spam-tab" role="tabpanel">
                                        <div class="card border-0">
                                            <div class="card-header border-0 p-5 mb-3">
                                                <div class="w-100 mb-5 position-relative">
                                                    <form class="search-form" action="https://wpthemebooster.com/demo/themeforest/html/kleon/search.php">
                                                        <input type="text" name="search" class="form-control rounded-3 w-100" placeholder="Search">
                                                        <button type="submit" class="btn"><img src="assets/img/svg/search.svg" alt=""></button>
                                                    </form>
                                                </div>
                                                <div class="dropdown-wrapper--title">
                                                    <h4 class="d-flex align-items-center justify-content-between text-uppercase text-gray">Recent Message 
                                                        <a href="#" data-bs-toggle="dropdown" class="fs-24 text-gray"><i class="bi bi-three-dots-vertical"></i></a>
                                                        
                                                        <div class="dropdown-menu p-0">
                                                            <a class="dropdown-item" href="#">Important</a>
                                                            <a class="dropdown-item" href="#">Trash</a>
                                                            <a class="dropdown-item" href="#">Important</a>
                                                        </div>
                                                    </h4>
                                                </div>
                                            </div>
                                            <div class="card-body p-0">
                                                <div class="dropdown-widget p-0">
                                                    <div class="dropdown-wrapper">
                                                        <ul class="notification-board list-unstyled">
                                                            <li class="author-online has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/10.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Margaretha <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/11.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">John Doe <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/12.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Marissa Joana <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/13.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Juminten <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/14.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Richard Hunters <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/15.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Clara Clarisa <span class="indicator info"></span> <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>

                                                            <li class="has-new-message">
                                                                <a href="#" class=" d-flex gap-3">
                                                                    <div class="media d-none d-sm-block">
                                                                        <img src="assets/img/16.jpg" alt="img" width="60" class="rounded-2">
                                                                    </div>
                                                                    <div class="user-message">
                                                                        <h6 class="message mb-1">Vasa Line <span class="fs-12 fw-normal text-gray float-end"> 12:45 PM</span></h6>
                                                                        <p class="message-footer d-flex align-items-center justify-content-between"> I remember that project due is tomorrow.</p>
                                                                    </div>
                                                                </a>
                                                            </li>
                                                        </ul>
                                                    </div>
                                                </div>                                            
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-5 ps-xxl-0">
                            <div class="card border-0 message-preview bg-light-200">
                                <div class="card-header bg-white d-flex align-items-center justify-content-between p-5">
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="media d-none d-sm-block">
                                            <img src="assets/img/14.jpg" alt="img" width="60" class="rounded-2">
                                        </div>
                                        <div class="user-message">
                                            <h6 class="message fs-20 text-dark mb-1">Application for UI Designer - Kleon Studio</h6>
                                            <p class="message-footer text-gray mb-0"> UI Designer / Product Design Team</p>
                                        </div>
                                    </div>
                                    <a href="#" data-bs-toggle="dropdown" class="fs-24 text-gray"><i class="bi bi-three-dots-vertical"></i></a>
                                                                
                                    <div class="dropdown-menu p-0">
                                        <a class="dropdown-item" href="#">Edit</a>
                                        <a class="dropdown-item" href="#">Remove</a>
                                        <a class="dropdown-item" href="#">Important</a>
                                    </div>
                                </div>
            
                                <div class="card-body">
                                    <div class="message--date text-center fs-12 fw-semibold text-dark">Today, October 25th 2020</div>
            
                                    <div class="message--body">
                                        <h5 class="message--sender fs-18 fw-semibold align-items-center justify-content-between">John Doe <time class="text-gray fs-14 fw-normal">12:45 PM</time> </h5>
                                        <div class="message--text p-4 rounded-3">
                                            <p>Hello Nella!</p>
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi</p>
                                            
                                            <h6 class="fs-14 fw-semibold text-gray text-uppercase mt-3"> <i class="bi bi-paperclip text-primary"></i> Attached Files</h6>
                                            <div class="d-flex align-items-center gap-3 flex-wrap">
                                                <a href="#" class="d-flex align-items-center gap-3 p-2 border border-light rounded-2">
                                                    <div class="rounded-1">
                                                        <img src="assets/img/presentation.png" alt="img" class="rounded-1" width="50" height="50">
                                                    </div>
                                                    <div>
                                                        <h6 class="ff-base fw-semibold mb-0">slide.ppt</h6>
                                                    </div>
                                                </a>
        
                                                <a href="#" class="d-flex align-items-center gap-3 p-2 border border-light rounded-2">
                                                    <div class="rounded-1">
                                                        <img src="assets/img/voice.png" alt="img" class="rounded-1" width="50" height="50">
                                                    </div>
                                                    <div>
                                                        <h6 class="ff-base fw-semibold mb-0">Voice.mp3</h6>
                                                    </div>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
            
                                    <div class="message--body reply">
                                        <h5 class="message--sender fs-18 fw-semibold align-items-center justify-content-between">You <time class="text-gray fs-14 fw-normal">12:45 PM</time> </h5>
                                        <div class="message--text p-4 rounded-3">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed</p>
                                        </div>
                                    </div>
            
                                    <!-- TinyMCE -->
                                    <form class="chat-form position-relative mt-5">
                                        <textarea id="defaulttextarea"></textarea>
                                        <div class="text-end mt-3">
                                            <div class="btn-group align-items-start">
                                                <button class="btn border-0 p-1 px-2 fs-30 rounded-2 text-primary m-0" type="button">
                                                    <i class="bi bi-emoji-smile-fill fs-30"></i> 
                                                </button>
                                                <button id="dpz-multiple-files" class="dropzone file-upload btn border-0 p-1 px-2 fs-30 rounded-2 text-primary m-0" type="button">
                                                    <div class="dz-message" data-dz-message><span><i class="bi bi-paperclip fs-30"></i></span></div>
                                                </button>
                                                <button class="btn btn-primary rounded-2 ff-heading fs-18 text-uppercase m-0 flex-shrink-0"> <i class="bi bi-send-fill me-2"></i> Send</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
@endsection  