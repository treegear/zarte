@extends('layouts.master')
@section('content')
<div class="container-fluid">
    <div class="inner-contents">
        <!-- Table One  -->
        <div class="card border-0 p-5">
            <div class="card-header pb-5 bg-transparent border-0 d-flex align-items-center justify-content-between gap-3">
                <h4 class="mb-0">{{$ps_type_val}}</h4>
                <div class="ms-auto d-flex align-items-center gap-3">
                     <a href="{{route($ps_type_val.'.create',base64_encode($ps_type_val))}}" class="btn btn-success"> Add {{$ps_type_val}}</a>
                </div>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table id="table-1" class="display text-center">
                        <thead>
                            <tr>
                                <th>Name</th> 
                                <th>Image</th> 
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($ps_data_list as $ps_row)

                                <tr> 
                                    <td>{{$ps_row->ps_name}}</td>
                                    <td><img src="{{asset('uploads/images/thumb/'.$ps_row->ps_img_1.'')}}"</td>
                                     
                                    <td></td>
                                </tr>
                            @endforeach
                                
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection