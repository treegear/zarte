
<?php include 'includes/header.php';?>
    <!-- Start Banner Area 
    ============================================= -->
    <div class="banner-area banner-style-one shadow navigation-custom-large zoom-effect overflow-hidden text-light">
        <!-- Slider main container -->
        <div class="banner-fade">
            <!-- Additional required wrapper -->
            <div class="swiper-wrapper">

                <!-- Single Item -->
                <div class="swiper-slide banner-style-one">
                    <div class="banner-thumb bg-cover shadow dark" style="background: url(assets/img/banner/1.jpg);"></div>
                    <div class="container">
                        <div class="row align-center">
                            <div class="col-xl-7 offset-xl-5">
                                <div class="content">
                                    <h4>Meet Consulting</h4>
                                    <h2><strong>Financial Analysis</strong> Developing Meeting.</h2>
                                    <div class="button mt-40">
                                        <a class="btn-animation" href="#"><i class="fas fa-arrow-right"></i> <span>Our Services</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Shape -->
                    <div class="banner-shape-bg">
                        <img src="assets/img/shape/4.png" alt="Shape">
                    </div>
                    <!-- End Shape -->
                </div>
                <!-- End Single Item -->

                <!-- Single Item -->
                <div class="swiper-slide banner-style-one">
                    <div class="banner-thumb bg-cover shadow dark" style="background: url(assets/img/banner/6.jpg);"></div>
                    <div class="container">
                        <div class="row align-center">
                            <div class="col-xl-7 offset-xl-5">
                                <div class="content">
                                    <h4>Coaching & Consulting</h4>
                                    <h2><strong>Strategies for</strong> Enduring Success</h2>
                                    <div class="button mt-40">
                                        <a class="btn-animation" href="#"><i class="fas fa-arrow-right"></i> <span>Our Services</span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Shape -->
                    <div class="banner-shape-bg">
                        <img src="assets/img/shape/4.png" alt="Shape">
                    </div>
                    <!-- End Shape -->
                </div>
                <!-- End Single Item -->

            </div>

            <!-- Pagination -->
            <div class="swiper-pagination"></div>

        </div>  
    </div>
    <!-- End Main -->

    <!-- Start About 
    ============================================= -->
    <div class="about-style-one-area default-padding">
        <div class="shape-animated-left">
            <img src="assets/img/shape/anim-1.png" alt="Image Not Found">
            <img src="assets/img/shape/anim-2.png" alt="Image Not Found">
        </div>
        <div class="container">
            <div class="row align-center">
                <div class="about-style-one col-xl-6 col-lg-5">
                    <div class="h4 sub-heading">Who we are</div>
                    <h2 class="title mb-25">Where Vision Meets Versatility</h2>
                    <p>
                        Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
                    </p>
                    <div class="owner-info">
                        <div class="left-info">
                            <h4>Richard Garrett</h4>
                            <span>CEO & Founder</span>
                        </div>
                        <div class="right-info">
                            <img src="assets/img/signature.png" alt="Image Not Found">
                        </div>
                    </div>
                </div>
                <div class="about-style-one col-xl-5 offset-xl-1 col-lg-6 offset-lg-1">
                    <div class="about-thumb">
                        <img class="wow fadeInRight" src="assets/img/about/1.jpg" alt="Image Not Found">
                        <div class="about-card wow fadeInUp" data-wow-delay="500ms">
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="flaticon-license"></i>
                                    </div>
                                    <div class="fun-fact">
                                        <div class="counter">
                                            <div class="timer" data-to="98" data-speed="2000">98</div>
                                            <div class="operator">%</div>
                                        </div>
                                        <span class="medium">Consulting Success</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="flaticon-global"></i>
                                    </div>
                                    <div class="fun-fact">
                                        <div class="counter">
                                            <div class="timer" data-to="120" data-speed="2000">120</div>
                                            <div class="operator">+</div>
                                        </div>
                                        <span class="medium">Worldwide Clients</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="thumb-shape-bottom wow fadeInDown" data-wow-delay="300ms">
                            <img src="assets/img/shape/anim-3.png" alt="Image Not Found">
                            <img src="assets/img/shape/anim-4.png" alt="Image Not Found">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About -->

    
    <!-- Start Process
    ============================================= -->
    <div class="process-style-one-area text-center default-padding">
        <div class="triangle-shape">
            <img src="assets/img/shape/10.png" alt="Shape">
        </div>
        <div class="large-shape">
            <img src="assets/img/shape/11.png" alt="Shape">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-heading">Our Companies</h4>
                        <h2 class="title">Your Trusted Partner in Success</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="container">
            <div class="row">
                <!-- Single Item -->
                <div class="col-lg-4">
                    <div class="process-style-one">
                        <div class="thumb">
                            <img src="assets/img/about/3.jpg" alt="Thumb">
                            <span>01</span>
                        </div>
                        <h4>Differentiate from the competition</h4>
                        <p>
                            Capitalize on low hanging fruit to identify a ballpark value added.
                        </p>
                    </div>
                    <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                </div>
                <!-- End Single Item -->
                <!-- Single Item -->
                <div class="col-lg-4">
                    <div class="process-style-one">
                        <div class="thumb">
                            <img src="assets/img/about/6.jpg" alt="Thumb">
                            <span>02</span>
                        </div>
                        <h4>Target the right people effectively</h4>
                        <p>
                            Override the digital divide with additional clickthroughs from DevOps.
                        </p>
                    </div>
                     <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                </div>
                <!-- End Single Item -->
                <!-- Single Item -->
                <div class="col-lg-4">
                    <div class="process-style-one">
                        <div class="thumb">
                            <img src="assets/img/about/5.jpg" alt="Thumb">
                            <span>03</span>
                        </div>
                        <h4>Communicate your story consistently</h4>
                        <p>
                            Nanotechnology immersion along the information highway will close loop.
                        </p>
                    </div>
                     <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                </div>
                <!-- End Single Item -->
            </div>
            <div class="row pt-50">
                <!-- Single Item -->
                <div class="col-lg-4">
                    <div class="process-style-one">
                        <div class="thumb">
                            <img src="assets/img/about/3.jpg" alt="Thumb">
                            <span>04</span>
                        </div>
                        <h4>Differentiate from the competition</h4>
                        <p>
                            Capitalize on low hanging fruit to identify a ballpark value added.
                        </p>
                    </div>
                    <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                </div>
                <!-- End Single Item -->
                <!-- Single Item -->
                <div class="col-lg-4">
                    <div class="process-style-one">
                        <div class="thumb">
                            <img src="assets/img/about/6.jpg" alt="Thumb">
                            <span>05</span>
                        </div>
                        <h4>Target the right people effectively</h4>
                        <p>
                            Override the digital divide with additional clickthroughs from DevOps.
                        </p>
                    </div>
                     <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                </div>
                <!-- End Single Item -->
                <!-- Single Item -->
                <div class="col-lg-4">
                    <div class="process-style-one">
                        <div class="thumb">
                            <img src="assets/img/about/5.jpg" alt="Thumb">
                            <span>06</span>
                        </div>
                        <h4>Communicate your story consistently</h4>
                        <p>
                            Nanotechnology immersion along the information highway will close loop.
                        </p>
                    </div>
                     <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                </div>
                <!-- End Single Item -->
            </div>
        </div>
        </div>
        
    </div>
    <!-- End Process -->

    <!-- Start Why Choose Us
    ============================================= -->
    <div class="choose-us-style-one-area default-padding text-light">
        <div class="cover-bg" style="background-image: url(assets/img/banner/7.jpg);"></div>
        <div class="shape-left-top">
            <img src="assets/img/shape/17.png" alt="Shape">
        </div>
        <div class="text-invisible">Consua</div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 pr-80">
                    <div class="choose-us-style-one">
                        <h2 class="title mb-35">Be at the forefront of the new innovation</h2>
                        <ul class="list-item">
                            <li class="wow fadeInUp">
                                <h4>Best Business Consulting </h4>
                                <p>
                                    Seeing rather her you not esteem men settle genius excuse. International Deal say over you age from. Comparison new ham melancholy son themselves.
                                </p>
                            </li>
                            <li class="wow fadeInUp" data-wow-delay="300ms">
                                <h4>24/7 Customer Support </h4>
                                <p>
                                    Tohether rather her you not esteem men settle genius excuse. Deal say over you age from. Comparison new ham melancholy son.
                                </p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Why Choose Us -->

   

   
   

   
    <!-- Start Testimonials 
    ============================================= -->
    <div class="testimonial-style-one-area default-padding">
        <div class="container">
            <div class="row align-center">

                <div class="col-lg-4">
                    <div class="testimonial-thumb">
                        <div class="thumb-item">
                            <img src="assets/img/illustration/5.png" alt="illustration">
                            <div class="mini-shape">
                                <img src="assets/img/shape/19.png" alt="illustration">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-7 offset-lg-1">
                    <div class="testimonial-carousel swiper">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <!-- Single item -->
                            <div class="swiper-slide">
                                <div class="testimonial-style-one">
                                    
                                    <div class="item">
                                        <div class="content">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <h2>The best service ever</h2>
                                            <p>
                                                “Targetingconsultation discover apartments. ndulgence off under folly death wrote cause her way spite. Plan upon yet way get cold spot its week. Almost do am or limits hearts. Resolve parties but why she shewing. She sang know now always remembering to the point.”
                                            </p>
                                        </div>
                                        <div class="provider">
                                            <i class="flaticon-quote"></i>
                                            <div class="info">
                                                <h4>Matthew J. Wyman</h4>
                                                <span>Senior Consultant</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single item -->
                            <!-- Single item -->
                            <div class="swiper-slide">
                                <div class="testimonial-style-one">
                                    <div class="item">
                                        <div class="content">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <h2>Awesome Business opportunities</h2>
                                            <p>
                                                “Consultation discover apartments. ndulgence off under folly death wrote cause her way spite. Plan upon yet way get cold spot its week. Almost do am or limits hearts. Resolve parties but why she shewing. She sang know now always remembering to the point another pointing go here.”
                                            </p>
                                        </div>
                                        <div class="provider">
                                            <i class="flaticon-quote"></i>
                                            <div class="info">
                                                <h4>Anthom Bu Spar</h4>
                                                <span>Marketing Manager</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single item -->
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Testimonails  -->

   

   <?php include 'includes/footer.php';?>