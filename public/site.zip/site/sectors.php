<?php include 'includes/subheader.php';?>
    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area bg-cover shadow dark text-center text-light" style="background-image: url(assets/img/banner/10.jpg);">
        <div class="breadcrum-shape">
            <img src="assets/img/shape/50.png" alt="Image Not Found">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h1>Our Services</h1>
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li>Service</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Aobut 
    ============================================= -->
    <div class="about-style-two-area overflow-hidden bg-contain default-padding" style="background-image: url(assets/img/shape/29.png);">
        <div class="container">
            <div class="row align-center">

                <div class="col-lg-5 about-style-two">
                    <div class="thumb">
                        <img src="assets/img/about/7.jpg" alt="Image Not Found">
                        <img src="assets/img/about/8.jpg" alt="Image Not Found">
                        <div class="experience">
                            <h2><strong>15</strong> Years experience</h2>
                        </div>
                        <div class="shape">
                            <img src="assets/img/shape/anim-5.png" alt="Shape">
                        </div>
                    </div>
                </div>

                <div class="about-style-two col-lg-6 offset-lg-1">
                    <h2 class="title">Finance Consulting for <br> Challenging Times</h2>
                    <p>
                        We work to understand your issues and are driven to ask better questions in the pursuit of making work. Me contained explained my education. Vulgar as hearts by garret. Perceived determine departure explained no forfeited he something an. Contrasted dissimilar get joy you instrument out reasonably. Again keep.
                    </p>
                    <div class="default-features mt-30">
                        <div class="default-feature-item">
                            <a href="#">
                                <i class="flaticon-investment-3"></i>
                                <h4>Targeting & <br> Positioning</h4>
                            </a>
                        </div>
                        <div class="default-feature-item">
                            <a href="#">
                                <i class="flaticon-progress"></i>
                                <h4>Unique Ideas <br> & Solution</h4>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End About -->

    <!-- Start Services 
    ============================================= -->
    <div class="services-style-two-area default-padding bottom-less bg-cover bg-gray" style="background-image: url(assets/img/shape/27.png);">
        <div class="container">
            <div class="row">

                <!-- Single Item -->
                <div class="col-xl-4 col-md-6 mb-30">
                    <div class="services-style-two active">
                        <div class="thumb">
                            <img src="assets/img/service/2.jpg" alt="Thumb">
                            <div class="title">
                                <a href="#">
                                    <i class="flaticon-budget"></i>
                                    <h4>Commercial Funds</h4>
                                </a>
                            </div>
                        </div>
                        <div class="info">
                            <p>
                                Continue indulged speaking the was out horrible for domestic position. Seeing rather her you not esteem men settle genius excuse.
                            </p>
                            <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Item -->

                <!-- Single Item -->
                <div class="col-xl-4 col-md-6 mb-30">
                    <div class="services-style-two">
                        <div class="thumb">
                            <img src="assets/img/service/3.jpg" alt="Thumb">
                            <div class="title">
                                <a href="#">
                                    <i class="flaticon-bar-chart"></i>
                                    <h4>Markets Research</h4>
                                </a>
                            </div>
                        </div>
                        <div class="info">
                            <p>
                                Technic indulged speaking the was out horrible for domestic position. Seeing rather her you not esteem men settle genius excuse.
                            </p>
                            <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Item -->

                <!-- Single Item -->
                <div class="col-xl-4 col-md-6 mb-30">
                    <div class="services-style-two">
                        <div class="thumb">
                            <img src="assets/img/service/4.jpg" alt="Thumb">
                            <div class="title">
                                <a href="#">
                                    <i class="flaticon-credit-cards"></i>
                                    <h4>Saving & Investments</h4>
                                </a>
                            </div>
                        </div>
                        <div class="info">
                            <p>
                                Librarian indulged speaking the was out horrible for domestic position. Seeing rather her you not esteem men settle genius excuse.
                            </p>
                            <div class="button">
                                <a href="#">Read More</a>
                                <div class="devider"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End Single Item -->

            </div>
        </div>
    </div>
    <!-- End Services -->

   

    <!-- Start Partner Area  
    ============================================= -->
    <div class="partner-style-one-area bg-gray default-padding">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-5">
                    <div class="partner-map" style="background-image: url(assets/img/shape/map.png);">
                        <h2 class="mask-text" style="background-image: url(assets/img/banner/10.jpg);">80</h2>
                        <h4>Partners in world wide</h4>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <div class="partner-items">
                        <ul>
                            <li><img src="assets/img/logo/1.png" alt="Image Not FOund"></li>
                            <li><img src="assets/img/logo/2.png" alt="Image Not FOund"></li>
                            <li><img src="assets/img/logo/7.png" alt="Image Not FOund"></li>
                            <li><img src="assets/img/logo/4.png" alt="Image Not FOund"></li>
                            <li><img src="assets/img/logo/5.png" alt="Image Not FOund"></li>
                            <li><img src="assets/img/logo/6.png" alt="Image Not FOund"></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Partner Area -->

   
    <!-- Start Request Call Back 
    ============================================= -->
    <div class="request-call-back-area text-light default-padding" style="background-image: url(assets/img/banner/13.jpg);">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-6">
                    <h2 class="title">Looking for a First-Class <br> Business Consultant?</h2>
                    <a class="btn circle btn-light mt-30 mt-md-15 mt-xs-10 btn-md radius animation" href="#">Request a Call back</a>
                </div>
                <div class="col-lg-6 text-end">
                    <div class="achivement-counter">
                        <ul>
                            <li>
                                <div class="icon">
                                    <i class="flaticon-handshake"></i>
                                </div>
                                <div class="fun-fact">
                                    <div class="counter">
                                        <div class="timer" data-to="500" data-speed="2000">500</div>
                                        <div class="operator">+</div>
                                    </div>
                                    <span class="medium">Business advices given over 30 years</span>
                                </div>
                            </li>
                            <li>
                                <div class="icon">
                                    <i class="flaticon-employee"></i>
                                </div>
                                <div class="fun-fact">
                                    <div class="counter">
                                        <div class="timer" data-to="30" data-speed="2000">30</div>
                                        <div class="operator">+</div>
                                    </div>
                                    <span class="medium">Business Excellence awards achieved</span>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Request Call Back  -->

    <!-- Start Testimonials 
    ============================================= -->
    <div class="testimonial-style-one-area default-padding">
        <div class="container">
            <div class="row align-center">

                <div class="col-lg-4">
                    <div class="testimonial-thumb">
                        <div class="thumb-item">
                            <img src="assets/img/illustration/5.png" alt="illustration">
                            <div class="mini-shape">
                                <img src="assets/img/shape/19.png" alt="illustration">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-7 offset-lg-1">
                    <div class="testimonial-carousel swiper">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <!-- Single item -->
                            <div class="swiper-slide">
                                <div class="testimonial-style-one">
                                    
                                    <div class="item">
                                        <div class="content">
                                            <p>
                                                “Targetingconsultation discover apartments. ndulgence off under folly death wrote cause her way spite. Plan upon yet way get cold spot its week. Almost do am or limits hearts. Resolve parties but why she shewing. She sang know now always remembering to the point.”
                                            </p>
                                        </div>
                                        <div class="provider">
                                            <i class="flaticon-quote"></i>
                                            <div class="info">
                                                <h4>Matthew J. Wyman</h4>
                                                <span>Senior Consultant</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single item -->
                            <!-- Single item -->
                            <div class="swiper-slide">
                                <div class="testimonial-style-one">
                                    <div class="item">
                                        <div class="content">
                                            <p>
                                                “Consultation discover apartments. ndulgence off under folly death wrote cause her way spite. Plan upon yet way get cold spot its week. Almost do am or limits hearts. Resolve parties but why she shewing. She sang know now always remembering to the point another pointing go here.”
                                            </p>
                                        </div>
                                        <div class="provider">
                                            <i class="flaticon-quote"></i>
                                            <div class="info">
                                                <h4>Anthom Bu Spar</h4>
                                                <span>Marketing Manager</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single item -->
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- End Testimonails  -->

   <?php include 'includes/footer.php';?>