<?php include 'includes/subheader.php';?>
    <!-- Start Breadcrumb 
    ============================================= -->
    <div class="breadcrumb-area bg-cover shadow dark text-center text-light" style="background-image: url(assets/img/banner/10.jpg);">
        <div class="breadcrum-shape">
            <img src="assets/img/shape/50.png" alt="Image Not Found">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h1>Our Companies</h1>
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                        <li>companies</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->

    <!-- Start Blog
    ============================================= -->
    <div class="blog-area full-blog blog-standard default-padding">
        <div class="container">
            <div class="row">
                <div class="blog-content col-xl-10 offset-xl-1 col-md-12">
                    <div class="blog-item-box">
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <a href="#"><img src="assets/img/blog/v1.jpg" alt="Thumb"></a>
                            </div>
                            <div class="info">
                               
                                <h2><a href="#">Company Name - 1</a></h2>
                                <p>
                                    Bndulgence diminution so discovered mr apartments. Are off under folly death wrote cause her way spite. Plan upon yet way get cold spot its week. Almost do am or limits hearts. Resolve parties but why she shewing. She sang know now
                                </p>
                                <a class="btn mt-10 btn-md circle btn-theme animation" href="#">Visit Website</a>
                            </div>
                        </div>
                        <!-- Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <a href="#"><img src="assets/img/blog/v2.jpg" alt="Thumb"></a>
                            </div>
                            <div class="info">
                                
                                <h2><a href="#">Company Name - 2</a></h2>
                                <p>
                                    Bndulgence diminution so discovered mr apartments. Are off under folly death wrote cause her way spite. Plan upon yet way get cold spot its week. Almost do am or limits hearts. Resolve parties but why she shewing. She sang know now
                                </p>
                                <a class="btn mt-10 btn-md circle btn-theme animation" href="#">Visit Website</a>
                            </div>
                        </div>
                        <!-- Single Item -->
                        <!-- Single Item -->
                        <div class="item">
                            <div class="thumb">
                                <a href="#"><img src="assets/img/blog/v3.jpg" alt="Thumb"></a>
                            </div>
                            <div class="info">
                                
                                <h2><a href="#">Company Name - 3</a></h2>
                                <p>
                                    Bndulgence diminution so discovered mr apartments. Are off under folly death wrote cause her way spite. Plan upon yet way get cold spot its week. Almost do am or limits hearts. Resolve parties but why she shewing. She sang know now
                                </p>
                                <a class="btn mt-10 btn-md circle btn-theme animation" href="#">Visit Website</a>
                            </div>
                        </div>
                        <!-- Single Item -->
                    </div>
                    
                   
                   
                </div>
            </div>
        </div>
    </div>
   
 <?php include 'includes/footer.php';?>