<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\VehicleEntry;

$factory->define(VehicleEntry::class, function (Faker $faker) {
    return [
        //
    ];
});
