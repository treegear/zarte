<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Supplier;

$factory->define(Supplier::class, function (Faker $faker) {
    return [
        //
    ];
});
