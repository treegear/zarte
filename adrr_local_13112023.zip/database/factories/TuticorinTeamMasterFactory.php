<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\TuticorinTeamMaster;

$factory->define(TuticorinTeamMaster::class, function (Faker $faker) {
    return [
        //
    ];
});
