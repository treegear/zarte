<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Cafentry;

$factory->define(Cafentry::class, function (Faker $faker) {
    return [
        //
    ];
});
