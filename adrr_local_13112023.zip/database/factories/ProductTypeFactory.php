<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\ProductType;

$factory->define(ProductType::class, function (Faker $faker) {
    return [
        //
    ];
});
