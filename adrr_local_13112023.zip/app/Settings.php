<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;

class Settings extends Model
{
     
    
		

}
