<?php

namespace App;
use DB;
use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
     
    
		

}
